<?php

//Login
$hn = "localhost";
$db = "fishrus";
$un = "root";
$pw = "root";

?>